/*
 * 基你太美.c
 * 
 * Copyright 2019 fcall <fcall@fcall-pc>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <stdio.h>
#include <stdlib.h>
#include <time.h>


float moneyall,moneyin,moneyout,dpzs,day=0,jjjz,zzc;   //定义总资金、仓位资金、可用资金,大盘指数、交易天数、基金净值
float ccfe=0,ccjz=0,dt=0,syl=0,dpzd=0,yszs,ysjz;     //定义持仓份额，持仓净值，定投，最大收益率
float down=0,up=0,buy=0,sell=0,innum=0,outnum=0,zdzs=0,zdzsnum=0,zdzy=0,zdzynum=0;           //复杂策略参数
float maxdpzs=0,mindpzs=0,maxsyl=0,minsyl=0,dpzsdown=0,dpzsup=0;       //记录最大最小大盘指数、最大最小收益率 大盘低处交易点 大盘高处交易点
int fzcl=0,zhisun=0,zhiying=0,zhisunkey=0,zhiyingkey=0,dtkey=0,zhisunsum=0,zhiyingsum=0;        //复杂策略、自动止损、自动止盈开关  止损止盈执行开关 定投开关 止损止盈次数         

int MNJY();      //定义模拟交易面板
int YLL();       //定义盈利率数据面板

int ZMB(){      //定义主面板
	
	zzc=ccfe*jjjz+moneyout;      //总资产
	if(moneyin==0)
		syl=0;
	else
	syl=((zzc-moneyall)/moneyin)*100; //收益率
	

	dpzd=(dpzs-yszs)/yszs*100;
	
	printf("\n\n\n\n");
	printf("*************************************************************************************************************\n\n\n");
	printf("*\t\t\t\t\t\t这里是主面板\n\n");
	
	printf("*\t现在是第%.0f天\n",day);
	printf("*\t您现在的总投入资金为%.2f元，仓位购入资金为%.2f元，现在大盘指数为%.2f点，大盘涨跌%.2f%%\n",moneyall,moneyin,dpzs,dpzd);
	printf("*\t您现在共有%.2f份该基金，价值%.2f元，总资产%.2f元，收益率%.2f%%，最大收益率%.2f%%\n",ccfe,ccfe*jjjz,zzc,syl,maxsyl);
	printf("*\t现有基金净值%.2f元,平均持仓成本%.2f元，交易策略为每天定投%.2f元\n*\t可用资金还有%.2f元\n\n",jjjz,ccjz,dt,moneyout);
	
	printf("*\t请选择选项：\n");        
	printf("*\t1.模拟交易\n");
	printf("*\t2.查看盈利率\n");
	printf("*\t3.重新开始\n");
	printf("*\t4.重置参数\n");
	printf("*\t5.查看系统使用说明\n");
	printf("\n\n\n"); 
	printf("*************************************************************************************************************\n\n");
	
	
	
	int j;
	printf("*\t");
	scanf("%d",&j);         
	switch(j)                  //选择下一步选项
	{
		case 1:MNJY();break;         //进入模拟交易面板
		case 2:                    //进入盈利率数据面板
				{
					
					
					printf("*\t此功能尚未开发，敬请等候！\n\n");

					int temp=1;
					do{
						printf("*\t输入0返回主菜单\n\n");
						printf("*\t");
						scanf("%d",&temp);
						if(temp==0)
						ZMB();
					   }while(temp!=0);
					
					break;  
					
										
				}	   
		case 3:{
					dpzs=yszs;      //重置大盘指数
					jjjz=ysjz;		//重置基金净值
					moneyout=moneyall;		
					mindpzs=yszs;			
					moneyin=0;ccfe=0,ccjz=0,dt=0,syl=0,dpzd=0;     //定义持仓份额，持仓净值，定投，最大收益率
					down=0,up=0,buy=0,sell=0,innum=0,outnum=0,zdzs=0,zdzsnum=0,zdzy=0,zdzynum=0;           //复杂策略参数
					maxdpzs=0,maxsyl=0,minsyl=0,dpzsdown=0,dpzsup=0;       //记录最大最小大盘指数、最大最小收益率 大盘低处交易点 大盘高处交易点
					fzcl=0,zhisun=0,zhiying=0,zhisunkey=0,zhiyingkey=0,dtkey=0,day=0,zhisunsum=0,zhiyingsum=0;        //复杂策略、自动止损、自动止盈开关  止损止盈执行开关 定投开关   
					ZMB();
					break;
					
				}
		case 4:{
					
					moneyin=0;ccfe=0,ccjz=0,dt=0,syl=0,dpzd=0;     //定义持仓份额，持仓净值，定投，最大收益率
					down=0,up=0,buy=0,sell=0,innum=0,outnum=0,zdzs=0,zdzsnum=0,zdzy=0,zdzynum=0;           //复杂策略参数
					maxdpzs=0,maxsyl=0,minsyl=0,dpzsdown=0,dpzsup=0;       //记录最大最小大盘指数、最大最小收益率 大盘低处交易点 大盘高处交易点
					fzcl=0,zhisun=0,zhiying=0,zhisunkey=0,zhiyingkey=0,dtkey=0,day=0,zhisunsum=0,zhiyingsum=0;        //复杂策略、自动止损、自动止盈开关  止损止盈执行开关 定投开关   
					
					printf("*\t请输入您的总资金、大盘指数、基金净值：\n");  //输入原始资金、仓位、指数
					printf("*\t");
					scanf("%f%f%f",&moneyall,&dpzs,&jjjz);
					moneyout=moneyall;             
					
					yszs=dpzs;            //记录大盘原始指数
					ysjz=jjjz;             //记录基原始净值
					mindpzs=yszs;
					ZMB(); 
					break;
					
				}
		case 5:{
					printf("*************************************************************************************************************\n\n\n");
					printf("*\t\t\t欢迎使用风尘制作的‘基你太美’基金模拟交易系统，此版本为V1.7\n\n");
					printf("*\t请选择您的选项：\n\n");
					printf("*\t1.查看使用说明\n");
					printf("*\t2.关于\n");
					printf("*\t3.Q&A\n");
					printf("*\t0.返回上级菜单\n\n");
					printf("\n\n\n*************************************************************************************************************\n");
					
					int i;
					printf("*\t");
					scanf("%d",&i);
					switch(i)
					{
						case 0:ZMB();break;
						case 1:{	
							
									printf("*************************************************************************************************************\n\n\n");
									printf("*\t\t\t\t\t\t这里是说明文档!\t\t\t\n\n");
									printf("*\t本系统拥有基金买卖、基金定投、复杂策略设定、手动自动输入涨跌情况、自动读取大盘数据、\n");
									printf("*\t随机生成牛市熊市稳定震荡四种情况、查看大盘涨跌、记录自己最高收益等功能，\n");
									printf("*\t并加入参数重置 方便用户重新模拟。\n\n");
									printf("*\t在进入模拟交易后，您可以一次性直接购买基金或设置定投策略，每日自动购买。设置负责策略进行自动跌买涨卖。\n");
									printf("*\t此类功能既可以全部不执行，也可以混合执行，方便用户模拟真实情况。\n");
									printf("*\t在设定好策略后，选择模拟运算，手动输入大盘涨跌涨跌指数（非百分比），或选择由计算机自动读取真实数据、随即生成模拟数据。\n");
									printf("*\t您可以修改位于文件夹下的data.txt文件，将您所收集的数据放入其中，请在文档结尾放置加上一个0，因为遇到0后系统才会停止读取。\n");
									printf("\n*\t如果你有什么其他疑问，欢迎联系fc_stdio@163.com  祝您好运！\n\n\n");
									printf("*************************************************************************************************************\n");
									
									
									
									
									
									int temp=1;
									do{
										printf("*\t输入0返回主菜单\n\n");
										printf("*\t");
										scanf("%d",&temp);
										if(temp==0)
										ZMB();
									}while(temp!=0);
								
								
								}
						
						case 2:{
									printf("*************************************************************************************************************\n\n\n");
									printf("*\t\t\t\t\t\t这里是关于文档!\t\t\t\n\n");
									printf("*\t本系统的开发目的为检测自己的定投策略是否准确，能否跑赢大盘指数，最后得出一个结论：熊市可定投，牛市直接买，震荡稳定不用管。\n\n");
									printf("*\t当然，您也可以输入自己的定投策略，检验其准确性。\n\n");
									printf("*\t本代码开源，您可以在符合开源协议的情况下使用，商业用途在取的风尘同意后，亦可免费使用\n\n");
									printf("*\t因水平有限，本系统暂无复杂图形界面，测试时间不长、可能在极端情况下出现些许bug，如有发现，请向风尘fc_stdio@163.com反映。\n\n\n");
									printf("*************************************************************************************************************\n");
									
									
									
									
									int temp=1;
									do{
										printf("*\t输入0返回主菜单\n\n");
										printf("*\t");
										scanf("%d",&temp);
										if(temp==0)
										ZMB();
									}while(temp!=0);
								
								
								}
								
								
						case 3:{
									
									printf("*************************************************************************************************************\n\n\n");
									printf("*\t\t\t\t\t\t这里是Q&A文档!\t\t\t\n\n");
									printf("*\tQ：这个系统开发的目的是为了什么？有什么想说的？\n");
									printf("*\tA：开发这个系统纯粹是因为想要检验自己的基金定投策略是否能赚钱，没有其他目的。\n");
									printf("*\t   投资有风险、入市需谨慎！\n\n");
									
									printf("*\tQ：这个系统开发用了多久？功能和稳定性如何？\n");
									printf("*\tA：V1.0版系统完成只用了不到1天，后来又用了整整一天更新了很多功能，开发时间应该是算比较短。\n");
									printf("*\t   目前的功能完全够用，但是因为开发时间较短、测试较少，可能会出现bug，稳定性总体还是可以的。\n\n");
									
									printf("*\tQ：以后还会有什么功能更新吗？\n");
									printf("*\tA：因为自己比较佛系，加上每天还要更新3500字的小说，所以没有太多时间和经历花在这个系统上面了，更新随缘吧。\n\n");
									
									printf("*\tQ：这个系统的代码水平怎么样？自身的能力水平怎么样？\n");
									printf("*\tA：代码还有很多可以优化的地方，总体水平比较粗浅，为了方便初学者阅读学习源代码，刻意使用了很基础的语法功能。\n");
									printf("*\t   （其实是自己也只会这么点(＾ω＾)）\n\n");
																		
									printf("*\tQ：代码好像有些冗余，不管一管吗？\n");
									printf("*\tA：这已经是个成熟的系统了，应该学会自己计划生育了！\n\n");
									
									printf("*\tQ：下步打算是什么？\n");
									printf("*\tA：将代码开源，扔到github上，让有兴趣的人来参与更新和修改吧。\n\n\n");
									
								
								
									printf("*************************************************************************************************************\n");
									
									
									
									int temp=1;
									do{
										printf("*\t输入0返回主菜单\n\n");
										printf("*\t");
										scanf("%d",&temp);
										if(temp==0)
										ZMB();
									  }while(temp!=0);
								
								
								}
								
						default:printf("*\t输入错误，返回主面板\n");ZMB();break;
						
						
						
					}
					
					
				}				
				
				
			
		default:printf("*\t输入错误，请重新输入：\n");ZMB();break;
		}
		return 0;
	
	}

int MNJY(){           //进入经济面板
	
	
	
	printf("*************************************************************************************************************\n\n\n");
	printf("*\t\t\t\t\t\t这里是模拟交易面板\n");
	
	printf("*\t现在是第%.0f天\n",day);
	printf("*\t您现在的总投入资金为%.2f元，仓位购入资金为%.2f元，现在大盘指数为%.2f点，大盘涨跌%.2f%%\n",moneyall,moneyin,dpzs,dpzd);
	printf("*\t现在共有%.2f份该基金，价值%.2f元，总资产%.2f元，收益率%.2f%%，最大收益率%.2f%%\n",ccfe,ccfe*jjjz,zzc,syl,maxsyl);
	printf("*\t现有基金净值%.4f元,平均持仓成本%.4f元，交易策略为每天定投%.2f元\n*\t可用资金还有%.2f元\n\n",jjjz,ccjz,dt,moneyout);
	
	printf("*\t请选择交易内容：\n");
	printf("*\t1.买入基金\n");
	printf("*\t2.卖出基金\n");
	printf("*\t3.定投策略\n");
	printf("*\t4.复杂自动买卖策略\n");
	printf("*\t5.自动加仓止盈设置\n");
	printf("*\t6.模拟市场变化运算\n");
	printf("*\t0.返回上级面板\n");
	printf("\n\n"); 
	printf("*************************************************************************************************************\n\n");
	
	
	int i;
	printf("*\t");
	scanf("%d",&i);
	switch(i)    //进行下一步选项
	{
		case 1:{
					printf("*\t现在的基金净值为%.2f,您有%.2f份基金，可用资金%.2f元，请输入您想买购买的金额：\n",jjjz,ccfe,moneyout);
					float num;
					printf("*\t");
					scanf("%f",&num); 
					if(num<=moneyout)
					{
						
						printf("*\t您已买入%.2f元该基金，共%.2f份\n",num,num/jjjz);
						
						int mrfe=num/jjjz;           					
						ccjz=(ccfe*ccjz+mrfe*jjjz)/(ccfe+mrfe);          //计算现有基金成本
						ccfe+=num/jjjz;       //计算现有基金持仓份额	
						moneyout-=num;
						moneyin+=num;
						printf("\n*\t您现在共有%.2f份该基金，基金净值%.4f元,平均持仓成本%.4f元\n*\t可用资金还有%.2f元\n\n",ccfe,jjjz,ccjz,moneyout);
						}
					else
						printf("*\t对不起，您的可用资金不足，无法购买！\n\n");
						
					int temp=1;
					do{
						printf("*\t输入0返回上一层\n");
						printf("*\t");
						scanf("%d",&temp);
						if(temp==0)
						MNJY();
					}while(temp!=0);
				
				    
			
			
			};break;
		case 2:{
					printf("*\t现在的基金净值为%.2f,您有%.2f份基金，可用资金%.2f元，请输入您想卖出的份额：\n",jjjz,ccfe,moneyout);
					float num;
					printf("*\t");
					scanf("%f",&num); 
					if(num<=ccfe)
					{
						
						printf("*\t您已卖出%.2f份该基金，共%.2f元\n",num,num*jjjz);
						
						int mcfe=num;           //计算现有基金持仓份额	
						if(ccfe-mcfe<0.1e-5f)
						ccjz=0;
						else					
						ccjz=(ccfe*ccjz-mcfe*jjjz)/(ccfe-mcfe);          //计算现有基金成本
						
						ccfe-=mcfe;   
						moneyout+=num*jjjz;
						moneyin-=num*jjjz;
						printf("\n*\t您现在共有%.2f份该基金，基金净值%.4f元,平均持仓成本%.4f元\n*\t可用资金还有%.2f元\n\n",ccfe,jjjz,ccjz,moneyout);
						}
					else
						printf("*\t对不起，您的可卖基金不足，无法交易！\n\n");
						
						
					int temp=1;
					do{
						printf("*\t输入0返回上一层\n");
						printf("*\t");
						scanf("%d",&temp);
						if(temp==0)
						MNJY();
					}while(temp!=0);
				
				    
				};break;
		case 3:{
				
				printf("*\t您现在的交易策略为每天定投%.2f元，请输入修改后每天定投的金额：\n\n",dt);
				printf("*\t");
				scanf("%f",&dt);
				printf("*\t修改成功！您现在的交易策略为，每天定投%.2f元！\n\n",dt);
				if(dt!=0)
					dtkey=1;
				else
					dtkey=0;
				
				int temp=1;
					do{
						printf("*\t输入0返回上一层\n");
						printf("*\t");
						scanf("%d",&temp);
						if(temp==0)
						MNJY();
					}while(temp!=0);
				
				
			
			}
		
		
		break;
		
		case 4:{
			     
			     if(fzcl==0)
					{
						printf("\n*\t您尚未设置复杂策略，请输入您的复杂策略：\n");
						printf("*\t请分别输入跌、买、涨、卖\n");
						printf("*\t如3 300 3 300，表示当日跌幅3%%时每超过1%%则额外买入300元基金，当日涨幅3%%时则每超过1%%卖出300份基金\n");
						printf("*\t注：不足1%%则按1%%买卖，如阀值为3%%，涨跌为4%%，则买入一次，涨跌为3.1%%也同样为买入一次\n\n");
						printf("*\t");
						scanf("%f%f%f%f",&down,&buy,&up,&sell);
						fzcl=1;
						
					}
				 else
					{
						printf("\n*\t您已设置复杂策略，目前的策略是当日跌幅%.2f%%则每超过1%%额外买入%.2f元基金，当日涨幅%.2f%%则每超过1%%卖出%.2f份基金 \n*\t是否要修改？ 1/0 \n\n",down,buy,up,sell);
					
						int temp;
						printf("*\t");
						scanf("%d",&temp);
						if(temp==1)
							{  
								printf("*\t请分别输入跌、买、涨、卖\n");
								printf("*\t如3 300 3 300，表示当日跌幅3%%时每超过1%%则额外买入300元基金，当日涨幅3%%时则每超过1%%卖出300份基金\n");
								printf("*\t注：不足1%%则按1%%买卖，如阀值为3%%，涨跌为4%%，则交易一次，涨跌为3.1%%也同样为交易一次\n");
								printf("*\t输入四个0则表示关闭复杂策略\n\n");
								printf("*\t");
								scanf("%f%f%f%f",&down,&buy,&up,&sell);
								if(down+buy+up+sell==0)    //如果都为0，则关闭复杂策略
									fzcl=0;
								else
									fzcl=1;
																							
						
							}
						
					
					}
					
								
					MNJY();
					
					break;
			     
				}
		
		
		case 5:{
			
					printf("*\t是否开启回转加仓策略？ 1/0 \n");
					printf("*\t回转加仓为：当大盘指数到达低处，开始回升并对未来大盘预期较好时，自动一次性买入一定金额基金。\n");
					printf("*\t");
					scanf("%d",&zhisun);
					if(zhisun==1)
						{
							printf("*\t回转加仓策略已开启！请输入你的回转止损值，如5 5000\n");
							printf("*\t如设为5 5000，则大盘比最低点回弹5%%的时候会一次性买入5000元。\n");
							printf("*\t");
							scanf("%f%f",&zdzs,&zdzsnum);
							printf("*\t回转加仓策略开始成功！\n\n");
							dpzsdown=dpzs/100*95;
						
						}	
						
					
					printf("*\t是否开启回转止盈策略？ 1/0 \n");
					printf("*\t回转止盈为：当盈利率到达最高处，开始回落并对未来大盘预期较差时，将一次性卖出所持基金。\n");
					printf("*\t");
					scanf("%d",&zhiying);
					if(zhiying==1)
						{
							printf("*\t回转止盈策略已开启！请输入你的回转止盈值，如10 3000\n");
							printf("*\t如设为10 3000，则盈利率回落10%%的时候会一次性卖出3000份基金。\n");
							printf("*\t");
							scanf("%f%f",&zdzy,&zdzynum);
							printf("*\t回转止盈策略开始成功！\n\n");
							dpzsup=dpzs/100*105;
						
						}
						
					int temp=1;
					do{
						printf("*\t输入0返回上一层\n");
						printf("*\t");
						scanf("%d",&temp);
						if(temp==0)
						MNJY();
					}while(temp!=0);
			
				}
		
		case 6:{
			
					printf("*\t请输入您的选择：\n");
					printf("*\t1.手动输入近日指数涨跌情况（100个交易日内），输入0提前停止\n");
					printf("*\t2.自动读取最近100个交易日的数据进行运算\n");
					printf("*\t3.随机生成5日牛市情况数据\n");
					printf("*\t4.随机生成5日熊市情况数据\n");
					printf("*\t5.随机生成5日震荡情况数据\n");
					printf("*\t6.随机生成5日稳定情况数据\n");
					printf("*\t0.返回模拟交易面板\n\n");
					
					
					float zszd[1000]={0};     //设定指数涨跌
					int jl=0;
			
					int in;
					printf("*\t");
					scanf("%d",&in);
					switch(in)
					{
							case 0:MNJY();break;
							case 1:{
										printf("*\t请输入近日指数涨跌数据：\n*\t");
										for(int i=0;i<1000;i++)
										{
											float temp;
											
											scanf("%f",&temp);    
											if(temp!=0)           //检测是否为零，不是就将其记录
											{
												zszd[i]=temp;     //记录指数涨跌
												jl++;            //记录输入几天
											}
											else break;
										}
								
										break;
									}
							
							case 2:{
										FILE *fpRead=fopen("date.txt","r");   //读取date里的数据
										
										for(i=0;i<1000;i++)
										   {	
											   float temp;										
											   fscanf(fpRead,"%f",&temp);    //读取单个数字
											   if(temp!=0)					//检测是否为0 
												{
													zszd[i]=temp;        //记录下来
													jl++;
												}
											   else break;
											}
								
										break;
								
									}
									
							case 3:{
									 srand((unsigned)time(NULL));            //新建五个随机数
									 for (int i = 0; i < 5; i++)			  //牛市情况
									   {
										 zszd[i]=rand()%150-30;
										 jl++;
									    }
									  break; 
								
								    }
							case 4:{
									 srand((unsigned)time(NULL));            //新建五个随机数
									 for (int i = 0; i < 5; i++)			  //熊市情况
									   {
										 zszd[i]=rand()%50-70;
										 jl++;
									    }
									  break; 
								
								    }
							case 5:{
									 srand((unsigned)time(NULL));            //新建五个随机数
									 for (int i = 0; i < 5; i++)             //震荡情况
									   {
										 zszd[i]=rand()%100-48;
										 jl++;
									    }
									  break; 
								
								    }	    
							
							case 6:{
									 srand((unsigned)time(NULL));            //新建五个随机数
									 for (int i = 0; i < 5; i++)			  //平稳
									   {
										 zszd[i]=rand()%20-9;
										 jl++;
									    }
									  break; 
								
								    }
							}
					
					
					
					
					
					for(int i=0;i<jl;i++)
					{
						float zdl;
						zdl=zszd[i]/dpzs*100;
						jjjz+=jjjz*(zszd[i]/(zszd[i]+dpzs));  //基金净值变化
						dpzs+=zszd[i];           //指数变化
						
						
						
						while(fzcl)       //复杂策略
							{
								
								
							   if(-zdl>down)     //超过跌值
							   {
								   innum=(int)-(zdl+down-0.99);   //确定买入数量 不足1%按1%计算
								   float num=innum*buy;           //确认额外购入金额
								   
								   if(num<=moneyout)
									{
										
										printf("*\t您已根据复杂策略额外买入%.2f元该基金，共%.2f份\n",num,num/jjjz);
										
										int mrfe=num/jjjz;           					
										ccjz=(ccfe*ccjz+mrfe*jjjz)/(ccfe+mrfe);          //计算现有基金成本
										ccfe+=num/jjjz;       //计算现有基金持仓份额	
										moneyout-=num;
										moneyin+=num;
										printf("\n*\t您现在共有%.2f份该基金，基金净值%.4f元,平均持仓成本%.4f元\n*\t可用资金还有%.2f元\n\n",ccfe,jjjz,ccjz,moneyout);
									}
									else
										printf("*\t对不起，您的可用资金不足，无法购买！\n\n");
								   
								   
								  }  
								  
								  
								  
							   if(zdl>up)     //超过涨值
								   {
									   outnum=(int)(zdl-up+0.999);   //确定卖出数量 不足1%按1%计算
									   float num=outnum*sell;           //确认额外卖出份额
									   
									   
									   if(num<=ccfe)
											{
												
												printf("*\t您已根据复杂策略卖出%.2f份该基金，共%.2f元\n",num,num*jjjz);
												
												int mcfe=num;           //计算现有基金持仓份额	
												if(ccfe-mcfe<0.1e-5f)
													ccjz=0;
												else					
													ccjz=(ccfe*ccjz-mcfe*jjjz)/(ccfe-mcfe);          //计算现有基金成本
												
												ccfe-=mcfe;   
												moneyout+=num*jjjz;
												moneyin-=num*jjjz;
												printf("\n*\t您现在共有%.2f份该基金，基金净值%.4f元,平均持仓成本%.4f元\n*\t可用资金还有%.2f元\n\n",ccfe,jjjz,ccjz,moneyout);
											}
										else
												printf("*\t对不起，您的可卖基金不足，无法卖出！\n\n");
									   
									   
									  } 
								  
									break;  
							   }
						
						
						while(zhisun&(day>1))
							{
								
								
								
								
								if((dpzs<dpzsdown)&&(dpzs>mindpzs))                 //当超过第一次的买点之后才能再次开启
									zhisunkey=1;
								else 
									zhisunkey=0;
									
								if((zhisunsum>=2)&&(dpzs>yszs))          //当指数回归本值时，重置最低点
									{dpzsdown=dpzs;	
										mindpzs=dpzs;
										zhisunsum=0;
										//printf("大盘指数%f 原始指数%f\n",dpzs,yszs);
							
									}
								
								if(zhisunkey==1)
								{
									float dphz;
									dphz=(dpzs-mindpzs)/mindpzs*100;    //将大盘回转与预设值相比较
									//printf("*\t大盘回值:%f\n",dphz);
									//printf("*\t大盘指数%f 交易最低值%f 大盘最低点%f\n",dpzs,dpzsdown,mindpzs);
									
									if(dphz>=zdzs)
										{
											float num;                //如果钱够，就买  不够就买完
											if(zdzsnum<=moneyout)
												num=zdzsnum;
											else
												num=moneyout;										
											
											if(num<=moneyout)
												{
													
													printf("*\t您已根据回转加仓策略额外买入%.2f元该基金，共%.2f份\n",num,num/jjjz);
													
													int mrfe=num/jjjz;           					
													ccjz=(ccfe*ccjz+mrfe*jjjz)/(ccfe+mrfe);          //计算现有基金成本
													ccfe+=num/jjjz;       //计算现有基金持仓份额	
													moneyout-=num;
													moneyin+=num;
													printf("\n*\t您现在共有%.2f份该基金，基金净值%.4f元,平均持仓成本%.4f元\n*\t可用资金还有%.2f元\n\n",ccfe,jjjz,ccjz,moneyout);
													dpzsdown=dpzs;  //记录最低交易点	
													
												}
												else
													printf("*\t对不起，您的可用资金不足，无法购买！\n\n");
												
												zhisunsum++;
									}
									zhisunkey=0;   //暂时关闭
								 }
								
								break;		
							}
						
						
						while(zhiying&(day>1))
							{
								
								
								if((dpzs<=maxdpzs)&&(dpzs>dpzsup))                 //当超过第一次的卖点之后才能再次开启
									zhiyingkey=1;
								else
									zhiyingkey=0;
									 
								if((zhiyingsum>=2)&&(dpzs<yszs))          //当指数回归本值时，重置最高点
											{
												dpzsup=dpzs;
												maxdpzs=dpzs;
												zhiyingsum=0;
												//printf("大盘交易最高线%f 最大大盘指数%f\n",dpzsup,maxdpzs);
											}
								
								if(zhiyingkey==1)
								{
									float dphz;
									dphz=(maxdpzs-dpzs)/maxdpzs*100;    //将大盘回转与预设值相比较
									printf("*\t大盘回值:%f\n",dphz);
									printf("*\t大盘指数%f 交易最高值%f 大盘最高点%f\n",dpzs,dpzsup,maxdpzs);
									
									if(dphz>=zdzy)
										{
											float num;                //如果份额够，就卖  不够就卖完
											if(zdzynum<=ccfe)
												num=zdzynum;
											else
												num=ccfe;										
											
											
											 if(num<=ccfe)
												{
													
													
													printf("*\t您已通过回转止损策略卖出%.2f份该基金，共%.2f元\n",num,num*jjjz);
													
													int mcfe=num;           //计算现有基金持仓份额	
													if(ccfe-mcfe<0.1e-5f)
														ccjz=0;
													else					
														ccjz=(ccfe*ccjz-mcfe*jjjz)/(ccfe-mcfe);          //计算现有基金成本
													
													ccfe-=mcfe;   
													moneyout+=num*jjjz;
													moneyin-=num*jjjz;
													printf("\n*\t您现在共有%.2f份该基金，基金净值%.4f元,平均持仓成本%.4f元\n*\t可用资金还有%.2f元\n\n",ccfe,jjjz,ccjz,moneyout);
													dpzsup=dpzs;																									
												}
											else
												printf("*\t对不起，您的可卖基金不足，无法卖出！\n\n");
												
											zhiyingsum++;								
																					
										} 
										
										zhiyingkey=0;
									}
									
									break;
								
							}
						
						
						
						
						
						while(dtkey)
						{
							if(dt<=moneyout)     //金钱足够则进行定投
								{
								
									printf("*\t您定投已买入%.2f元该基金，共%.2f份\n",dt,dt/jjjz);
									
									int mrfe=dt/jjjz; 
									 
															
									ccjz=(ccfe*ccjz+mrfe*jjjz)/(ccfe+mrfe);          //计算现有基金成本
										
									ccfe+=dt/jjjz;       //计算现有基金持仓份额	
									moneyout-=dt;
									moneyin+=dt;
									printf("\n*\t您现在共有%.2f份该基金，基金净值%.4f元,平均持仓成本%.4f元\n*\t可用资金还有%.2f元\n\n",ccfe,jjjz,ccjz,moneyout);
								}
							else
								{
									printf("*\t对不起，您的可用资金不足，定投未完成！\n\n");
								}
								break;
							
						 }
								
							
							zzc=ccfe*jjjz+moneyout;      //总资产
							if(moneyin==0)
								syl=0;
							else
								syl=((zzc-moneyall)/moneyin)*100; //收益率
							moneyin=ccfe*jjjz;   //可用资金
							dpzd=(dpzs-yszs)/yszs*100;
							maxsyl=(maxsyl>syl?maxsyl:syl);   //获取最大收益率
							minsyl=(minsyl<syl?minsyl:syl);    //最小收益率
							maxdpzs=(maxdpzs>dpzs?maxdpzs:dpzs);   //大盘最大涨幅
							mindpzs=(mindpzs<dpzs?mindpzs:dpzs);   //大盘最大跌幅
								
							day++;
							
						
						}
					
			
			
					MNJY();
			
					
					break;
					case 0:ZMB();break;
					default:printf("*\t输入错误，请重新输入：\n");MNJY();break;
					}
	
	
	
	
	}
	return 0;
	}

	
int main()
{
	printf("*************************************************************************************************************\n");
	printf("*\t\t\t\t\t\t基金模拟交易系统\n");
	printf("*\n");
	printf("*\t\t\t\t\t\t  V1.7  by风尘\n");
	printf("*************************************************************************************************************\n\n");
	printf("\n\n*\t请输入您的总资金、大盘指数、基金净值：\n");  //输入原始资金、仓位、指数
	
	
	printf("*\t");
	scanf("%f%f%f",&moneyall,&dpzs,&jjjz);
	moneyout=moneyall;             
	
	yszs=dpzs;            //记录大盘原始指数
	ysjz=jjjz;             //记录基原始净值
	mindpzs=dpzs;      //读取大盘最低值
	
	
	
	ZMB();
	
	return 0;
}

